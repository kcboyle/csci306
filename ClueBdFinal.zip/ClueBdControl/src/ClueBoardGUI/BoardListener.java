package ClueBoardGUI;

public class BoardListener {

}
