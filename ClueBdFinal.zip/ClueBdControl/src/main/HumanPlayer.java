/** Nicola Hetrick
 * Kira Combs
 * 10/26/12
 */
package main;

import java.util.ArrayList;

public class HumanPlayer extends Player {

	
	public HumanPlayer() {
		ArrayList<Card> cards = new ArrayList<Card>();
		setCards(cards);
		setLastRoomVisited('X');
	}

}
